# import shutil

# directory_to_remove = "archive_name.zip"
# shutil.rmtree(directory_to_remove)
import os

file_to_remove = "archive_name.zip"
os.remove(file_to_remove)
