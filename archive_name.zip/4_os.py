import shutil

source_dir = "OS Module"
shutil.make_archive("archive_name", "zip", source_dir)
